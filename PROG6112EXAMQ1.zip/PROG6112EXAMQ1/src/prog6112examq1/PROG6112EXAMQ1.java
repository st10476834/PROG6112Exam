/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112examq1;

/**
 *
 * @author husnawoodley
 */
public class PROG6112EXAMQ1 {

 public static void main(String[] args) {
        // Sample product sales data (2 years × 3 quarters)
        int[][] productSales = {
            {300, 150, 700},
            {250, 200, 600}
        };

        // Create instance of ProductSales
        ProductSales ps = new ProductSales();

        // Call the report function
        displayReport(productSales, ps);
    }

    // Function to generate and display the sales report
    public static void displayReport(int[][] productSales, ProductSales ps) {
        int totalSales = ps.TotalSales(productSales);
        double averageSales = ps.AverageSales(productSales);
        int maxSale = ps.MaxSale(productSales);
        int minSale = ps.MinSale(productSales);

        System.out.println("=========================================");
        System.out.println("      PRODUCT SALES REPORT - 2025");
        System.out.println("=========================================");
        System.out.println("Total Sales:   " + totalSales);
        System.out.printf("Average Sales: %.2f\n", averageSales);
        System.out.println("Maximum Sale:  " + maxSale);
        System.out.println("Minimum Sale:  " + minSale);
        System.out.println("=========================================");
    }
    
}
