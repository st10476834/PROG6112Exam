/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog6112examq1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aliyuyahaya
 */
public class ProductSalesTest {
    
    public ProductSalesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    int[][] productSales = {
        {300, 150, 700},
        {250, 200, 600}
    };

    ProductSales ps = new ProductSales();

    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
        int expected = 2200; // 300+150+700+250+200+600
        int result = ps.TotalSales(productSales);
        assertEquals("Total sales should equal 2200", expected, result);
    }

    @Test
    public void AverageSales_ReturnsAverageProductSales() {
        double expected = 2200.0 / 6; // 366.67
        double result = ps.AverageSales(productSales);
        assertEquals("Average sales should equal 366.67", expected, result, 0.01);
    }

    @Test
    public void MaxSale_ReturnsHighestValue() {
        int expected = 700;
        int result = ps.MaxSale(productSales);
        assertEquals("Max sale should equal 700", expected, result);
    }

    @Test
    public void MinSale_ReturnsLowestValue() {
        int expected = 150;
        int result = ps.MinSale(productSales);
        assertEquals("Min sale should equal 150", expected, result);
    }
}
