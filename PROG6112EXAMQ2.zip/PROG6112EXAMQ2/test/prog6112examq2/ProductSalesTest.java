/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog6112examq2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author husnawoodley
 */
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ProductSalesTest {
    private ProductSales productSales;

    @Before
    public void setUp() {
        productSales = new ProductSales();
    }

    @Test
    public void GetSalesOverLimit_ReturnsNumberOfSales() {
        assertEquals(2, productSales.GetSalesOverLimit());
    }

    @Test
    public void GetSalesUnderLimit_ReturnsNumberOfSales() {
        assertEquals(4, productSales.GetSalesUnderLimit());
    }
}
