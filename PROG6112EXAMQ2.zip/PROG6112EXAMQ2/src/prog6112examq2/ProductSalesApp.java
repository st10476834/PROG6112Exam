/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112examq2;

/**
 *
 * @author husnawoodley
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class ProductSalesApp extends JFrame {
    private JTextArea textArea;
    private JLabel lblYearsProcessed;
    private ProductSales productSales;

    public ProductSalesApp() {
        super("Product Sales Application");
        productSales = new ProductSales();

        // GUI setup
        textArea = new JTextArea(10, 30);
        textArea.setEditable(false);
        lblYearsProcessed = new JLabel("Years Processed: 0");

        JButton btnLoad = new JButton("Load Product Data");
        JButton btnSave = new JButton("Save Product Data");

        JPanel panel = new JPanel();
        panel.add(btnLoad);
        panel.add(btnSave);
        panel.add(lblYearsProcessed);

        add(new JScrollPane(textArea), BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);

        // Menu bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");

        fileMenu.add(exitItem);
        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        // Event listeners
        btnLoad.addActionListener(e -> loadData());
        loadItem.addActionListener(e -> loadData());

        btnSave.addActionListener(e -> saveData());
        saveItem.addActionListener(e -> saveData());

        clearItem.addActionListener(e -> clearData());
        exitItem.addActionListener(e -> System.exit(0));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadData() {
        StringBuilder sb = new StringBuilder();
        sb.append("DATA LOG\n");
        sb.append("Total Sales: ").append(productSales.GetTotalSales()).append("\n");
        sb.append("Average Sales: ").append((int) productSales.GetAverageSales()).append("\n");
        sb.append("Sales over limit: ").append(productSales.GetSalesOverLimit()).append("\n");
        sb.append("Sales under limit: ").append(productSales.GetSalesUnderLimit()).append("\n");
        sb.append("\nYears Processed: ").append(productSales.GetProductsProcessed());
        textArea.setText(sb.toString());
        lblYearsProcessed.setText("Years Processed: " + productSales.GetProductsProcessed());
    }

    private void saveData() {
        try (PrintWriter writer = new PrintWriter("data.txt")) {
            writer.println(textArea.getText());
            JOptionPane.showMessageDialog(this, "Data saved to data.txt");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving data.");
        }
    }

    private void clearData() {
        textArea.setText("");
        lblYearsProcessed.setText("Years Processed: 0");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ProductSalesApp::new);
    }
}

